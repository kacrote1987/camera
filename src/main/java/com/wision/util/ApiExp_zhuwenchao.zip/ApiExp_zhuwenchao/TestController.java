package com.wision.controller.api.example;


import com.wision.controller.api.example.youshu.YouShuComponent;
import cn.com.citydo.jxprovinceproject.common.service.ProjectExamineApproveService;
import cn.com.citydo.jxprovinceproject.entity.dto.examine.RemoteExamineDto;
import cn.com.citydo.jxprovinceproject.utils.JsonUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.citydo.comm.httpmodel.HttpResultModel;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.util.Assert;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.constraints.NotEmpty;
import java.util.HashMap;
import java.util.List;

/**
 * @author FanJunjie
 * @since 2020/8/20
 */
@Validated
@RestController
@RequestMapping("test")
@Api(value = "test", tags = "内测功能相关API")
public class TestController {

    @Resource
    YouShuComponent youShuComponent;
    @Resource
    ProjectExamineApproveService examineApproveService;

    @GetMapping("one")
    @ApiOperation(value = "根据appSecret刷新requestSecret")
    @ApiImplicitParam(name = "identifyCode", value = "口令", required = true, dataType = "String", paramType = "query")
    public HttpResultModel testOne(@RequestParam @NotEmpty(message = "口令不能为空") String identifyCode) {

        Assert.isTrue(identifyCode.equals("96371"), "请输入正确的口令");
        youShuComponent.updateRequestSecretByAppSecret();
        return HttpResultModel.success();
    }

    @GetMapping("two")
    @ApiOperation(value = "根据RefreshSecret更新request密钥")
    @ApiImplicitParam(name = "identifyCode", value = "口令", required = true, dataType = "String", paramType = "query")
    public HttpResultModel testTwo(@RequestParam @NotEmpty(message = "口令不能为空") String identifyCode) {

        Assert.isTrue(identifyCode.equals("96371"), "请输入正确的口令");
        youShuComponent.updateRequestSecretByRefreshSecret();
        return HttpResultModel.success();
    }

    @GetMapping("project-approve")
    @ApiOperation(value = "测试项目办件信息与批文")
//    @ApiImplicitParam(name = "identifyCode", value = "口令", required = true, dataType = "String", paramType = "query")
//    @ApiImplicitParam(name = "requestparam", value = "口令", required = true, dataType = "String", paramType = "query")
    public HttpResultModel testTwo(@ApiParam(value = "口令") @RequestParam @NotEmpty(message = "口令不能为空") String identifyCode,
                                   @ApiParam(value = "type") @RequestParam(required = true) String type,
                                   @ApiParam(value = "requestparam") @RequestParam(required = true) String requestparam) {

        Assert.isTrue(identifyCode.equals("96371"), "请输入正确的口令");
        HashMap<String,Object> map = new HashMap<>(16);
        map.put("type",type);
        map.put("requestparam",requestparam);
        List<RemoteExamineDto> examineApproveListByProjectCode = examineApproveService.getExamineList(map);
        return  HttpResultModel.success(examineApproveListByProjectCode);
    }

}
