package com.wision.controller.api.example.youshu;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * @Description 省政务建设平台密钥刷新
 * @author FanJunJie
 * @date 2021/3/29
 */
@Data
@Accessors(chain = true)
@ApiModel(value="KeySecret")
@TableName(value = "youshu_key_secret")
public class KeySecret implements Serializable {

    @TableId(value = "app_key",type = IdType.INPUT)
    @ApiModelProperty(value="appKey")
    private String appKey;

    @TableField(value = "app_secret")
    @ApiModelProperty(value="app_secret")
    private String appSecret;

    @TableField(value = "refresh_secret")
    @ApiModelProperty(value="刷新密钥")
    private String refreshSecret;

    @TableField(value = "request_secret")
    @ApiModelProperty(value="请求密钥")
    private String requestSecret;

    @TableField(value = "refresh_modify_time")
    @ApiModelProperty(value="refresh_secret 更新时间")
    private Date refreshModifyTime;

    @TableField(value = "request_modify_time")
    @ApiModelProperty(value="request_secret 更新时间")
    private Date requestModifyTime;

    @TableField(value = "refresh_secret_end_time")
    @ApiModelProperty(value="refresh_secret  到期时间")
    private Date refreshSecretEndTime;

    @TableField(value = "request_secret_end_time")
    @ApiModelProperty(value="request_secret 到期时间")
    private Date requestSecretEndTime;

    private static final long serialVersionUID = 1L;
}