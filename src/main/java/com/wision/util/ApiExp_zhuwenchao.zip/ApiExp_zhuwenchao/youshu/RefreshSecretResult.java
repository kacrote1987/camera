package com.wision.controller.api.example.youshu;

import lombok.Data;

@Data
public class RefreshSecretResult {

    private String code;
    private String msg;
    private String data;
    private Datas datas;
    private int dataCount;
    private String requestId;
    private String interfaces;

    @Data
    public
    class Datas {

        private String refreshSecret;
        private long refreshSecretEndTime;
        private String requestSecret;
        private long requestSecretEndTime;
    }
}

