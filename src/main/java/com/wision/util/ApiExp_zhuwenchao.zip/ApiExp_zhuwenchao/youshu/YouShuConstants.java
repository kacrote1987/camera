package com.wision.controller.api.example.youshu;

/**
 * @ClassName: YouShuConstants
 * @Author: zhuwc
 * @Description:
 * @Date: 2022/4/24 11:02
 * @Version: 1.0
 */
public interface YouShuConstants {
    String SUCCESS_CODE = "00";
    String SUCCESS_CODE_2 = "200";
    String CODE = "code";
    String DATA = "data";
    String DATAS = "datas";
    String EMPTY = "[]";
}
