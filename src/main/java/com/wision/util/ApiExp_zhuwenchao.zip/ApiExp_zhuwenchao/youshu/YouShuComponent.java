package com.wision.controller.api.example.youshu;

import cn.com.citydo.jxprovinceproject.common.exception.EiErrorCode;
import cn.com.citydo.jxprovinceproject.dao.KeySecretMapper;
import cn.com.citydo.jxprovinceproject.utils.http.HttpClientUtils;
import cn.com.citydo.jxprovinceproject.utils.http.RestTemplateComponent;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.citydo.comm.exception.CommonException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.util.DigestUtils;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * @author FanJunJie
 * @Description
 * @date 2021/3/29
 */
@Slf4j
@Component
public class YouShuComponent {
    @Value("${you-shu-service}")
    private String youShu;

    @Resource
    RestTemplateComponent restTemplateComponent;

    @Autowired
    KeySecretMapper keySecretMapper;
    @Resource
    UpdateKeyService updateKeyService;


    @PostConstruct
    public void init() {
        //投资项目办件信息与批文
        this.projectApproveUrl = youShu + "/api/001003002/dataSharing/462FVD4GpaMJB289.htm";

        this.refreshTokenBySecUrl = youShu + "/app/refreshTokenBySec.htm";
        this.refreshTokenByKeyUrl = youShu + "/app/refreshTokenByKey.htm";
    }

    /**
     * 投资项目办件信息与批文
     *
     * @param map
     * @return
     */
    private String projectApproveUrl;

    public JSONArray projectApprove(Map<String, Object> map) {
        JSONArray jsonArray = JSON.parseArray((String) getData(projectApproveUrl, map));

//        String dataCode = jsonObject.getString("code");
//        if (!dataCode.equals("200")){ throw new CommonException(EiErrorCode.SYSTEM_ERROR, "第三方接口调用异常");}
//
//        JSONObject data = jsonObject.getJSONObject("data");
        return jsonArray;
    }


    /**
     * 请求有数接口并剥离第三方接口返回体
     *
     * @param path
     * @param parameter
     * @return
     */
    public Object getData(String path, Map<String, Object> parameter) {

        // 封装公共参数
        KeySecret keySecret = keySecretMapper.selectOne(new LambdaQueryWrapper<KeySecret>().last("limit 1"));
        parameter.putAll(getCommonParameterMap(keySecret.getAppKey(), keySecret.getRequestSecret()));

        // 接口路径拼接
        String url = restTemplateComponent.pathUrlBuild(path, parameter);
        log.warn(">>>>>>>>>>>>>>>>>>>>>接口URL地址:{}", url);

        // 数据获取
        String body = null;
        try {
            body = HttpClientUtils.postForm(url);
        } catch (Exception e) {
            log.error("有数接口错误" + e.getMessage());
            throw new CommonException(EiErrorCode.ERROR_SIGN_YOU_SHU, "有数接口错误" + e.getMessage());
        }
        log.warn(">>>>>>>>>>>>>>>>>>>>>>>>>>有数返回体:{}", body);
        if (StringUtils.isBlank(body)) {
            throw new CommonException(EiErrorCode.ERROR_SIGN_YOU_SHU);
        }

        // 接口数据判断
        JSONObject jsonObject = JSON.parseObject(body);
        String code = jsonObject.getString("code");
        if (StringUtils.isBlank(code) || !code.equals("00")) {
            throw new CommonException(EiErrorCode.ERROR_SIGN_YOU_SHU, Optional.ofNullable(jsonObject.getString("msg")).orElse("调用有数接口异常"));
        }

        // 返回数据
        Object dataObject = jsonObject.get("datas");
        log.warn(">>>>>>>>>>>>>>>>>>>>>>>>>>>第三方接口返回数据:{}", dataObject);
        return dataObject;
    }


    /**
     * 根据appSecret刷新requestSecret
     * (此方法一天只能调用5次，超过次数后会向用户发送短信)
     */
    private String refreshTokenByKeyUrl;

    public void updateRequestSecretByAppSecret() {

        KeySecret keySecret = keySecretMapper.selectOne(new LambdaQueryWrapper<KeySecret>().last("limit 1"));

        String appKey = keySecret.getAppKey();
        String appSecret = keySecret.getAppSecret();

        // 拼接有数url
        String url = pathBuild(appKey, appSecret, refreshTokenByKeyUrl);
        log.info(">>>>>>>>>>>>>秘钥刷新url:{}", url);

        updateKeyService.updateKeySecret(keySecret, url);
    }

    /**
     * 根据RefreshSecret更新request密钥
     */
    private String refreshTokenBySecUrl;

    public void updateRequestSecretByRefreshSecret() {
        KeySecret keySecret = keySecretMapper.selectOne(new LambdaQueryWrapper<KeySecret>().last("limit 1"));

        String appKey = keySecret.getAppKey();
        String refreshSecret = keySecret.getRefreshSecret();

        // 拼接有数url
        String url = pathBuild(appKey, refreshSecret, refreshTokenBySecUrl);
        log.info(">>>>>>>>>>>>>秘钥刷新url:{}", url);

        updateKeyService.updateKeySecret(keySecret, url);
    }



    /**
     * 构建路径
     *
     * @param appKey
     * @param appSecret
     * @param url
     * @return
     */
    public String pathBuild(String appKey, String appSecret, String url) {
        HashMap<String, Object> parameter = getCommonParameterMap(appKey, appSecret);
        return restTemplateComponent.pathUrlBuild(url, parameter);
    }

    /**
     * 封装公共参数
     *
     * @param appKey
     * @param appSecret
     * @return
     */
    private HashMap<String, Object> getCommonParameterMap(String appKey, String appSecret) {
        long time = System.currentTimeMillis();
        String signStr = appKey + appSecret + time;
        String sign = DigestUtils.md5DigestAsHex(signStr.getBytes());

        HashMap<String, Object> parameter = new HashMap<>();
        parameter.put("appKey", appKey);
        parameter.put("sign", sign);
        parameter.put("requestTime", time);
        return parameter;
    }

    public String getRefreshTokenByKeyUrl(){
        return this.refreshTokenByKeyUrl;
    }
}
