package com.wision.controller.api.example.youshu;

import cn.com.citydo.jxprovinceproject.common.exception.EiErrorCode;
import cn.com.citydo.jxprovinceproject.dao.KeySecretMapper;
import cn.com.citydo.jxprovinceproject.utils.http.RestTemplateComponent;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSON;
import com.citydo.comm.exception.CommonException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.Map;

/**
 * @ClassName: UpdateKeyService
 * @Author: zhuwc
 * @Description:
 * @Date: 2022/4/24 14:38
 * @Version: 1.0
 */

@Component
@Slf4j
public class UpdateKeyService {
    @Resource
    RestTemplateComponent restTemplateComponent;

    @Resource
    KeySecretMapper keySecretMapper;

    @Resource
    YouShuComponent youShuComponent;
    /**
     * 更新密钥
     *
     * @param keySecret
     * @param url
     */
    @Retryable(value = Exception.class,maxAttempts = 5,backoff = @Backoff(delay = 2000L,multiplier = 1),recover="updateKeySecretRecover")
    public void updateKeySecret(KeySecret keySecret, String url) {
        updateNow(keySecret,url);
    }

    @Recover
    private void updateKeySecretRecover(Exception exception,KeySecret keySecret, String url) {
        log.warn(">>>>>>>>>>>>>秘钥刷新重试recover");
        String recoverUrl = youShuComponent.pathBuild(keySecret.getAppKey(), keySecret.getAppSecret(), youShuComponent.getRefreshTokenByKeyUrl());
        updateNow(keySecret,recoverUrl);
    }


    private void updateNow(KeySecret keySecret, String url){
        ResponseEntity<String> result = restTemplateComponent.post(url, null, String.class);
        if (!result.getStatusCode().equals(HttpStatus.OK) || !checkRefreshKey(result)) {
            throw new CommonException(EiErrorCode.ERROR_SIGN_YOU_SHU, "更新请求密钥异常");
        }
        String body = result.getBody();
        log.warn(">>>>>>>>>>>>>秘钥刷新请求返回体{}", body);
        RefreshSecretResult refreshSecretResult = JSON.parseObject(body, RefreshSecretResult.class);
        RefreshSecretResult.Datas datas = refreshSecretResult.getDatas();

        Date time = new Date();
        keySecret.setRefreshSecret(datas.getRefreshSecret())
                .setRefreshSecretEndTime(new Date(datas.getRefreshSecretEndTime()))
                .setRequestSecret(datas.getRequestSecret())
                .setRequestSecretEndTime(new Date(datas.getRequestSecretEndTime()))
                .setRefreshModifyTime(time)
                .setRequestModifyTime(time);

        //更新request秘钥
        keySecretMapper.updateById(keySecret);
    }

    public static boolean checkRefreshKey(ResponseEntity<String> result) {
        boolean isOk = result.getStatusCode().is2xxSuccessful();
        if (!isOk) {
            return false;
        }
        Map<String, Object> map = JSON.parseObject(result.getBody(), Map.class);
        Object code = map.get(YouShuConstants.CODE);
        boolean isSu = code.equals(YouShuConstants.SUCCESS_CODE);
        if (!isSu) {
            return false;
        }
        Object o = map.get(YouShuConstants.DATAS);
        if (ObjectUtil.isNull(o) || YouShuConstants.EMPTY.equals(o.toString())) {
            return false;
        }
        return true;
    }
}
